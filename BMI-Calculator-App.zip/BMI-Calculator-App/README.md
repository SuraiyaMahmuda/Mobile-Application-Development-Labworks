# BMI-Calculator-App
A mini project in Android Studio Project
