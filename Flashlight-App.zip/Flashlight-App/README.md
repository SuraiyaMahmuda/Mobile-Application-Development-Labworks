# Flashlight-App
A mini project in Android Studio Project
