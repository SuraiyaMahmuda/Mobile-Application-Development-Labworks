package com.example.restaurant;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private FoodExpert expert = new FoodExpert();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onClickSeekMenu(View view) {
        // Get the Spinner and the selected meal
        Spinner mealSpinner = findViewById(R.id.MealSpinner);
        String selectedMeal = (String) mealSpinner.getSelectedItem();

        // Retrieve the menu list based on the selected meal
        List<String> menuList = expert.getMenu(selectedMeal);

        // Check if menuList is null or empty
        if (menuList == null || menuList.isEmpty()) {
            menuList = List.of("No menu available for the selected meal."); // Provide a fallback message
        }

        // Format the menu list for display
        StringBuilder menuFormatted = new StringBuilder();
        for (String menu : menuList) {
            menuFormatted.append(menu).append('\n');
        }

        // Display the formatted menu in the TextView
        TextView menuTextView = findViewById(R.id.MenuTextView);
        menuTextView.setText(menuFormatted.toString());
    }
}
